// $ANTLR 2.7.6 (2005-12-22): "gramatica.g" -> "MeuParser.java"$

public interface MeuParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int LITERAL_programa = 4;
	int LITERAL_declare = 5;
	int T_Id = 6;
	int T_virg = 7;
	int T_pontof = 8;
	int LITERAL_fimprog = 9;
	int LITERAL_leia = 10;
	int T_ap = 11;
	int T_fp = 12;
	int LITERAL_escreva = 13;
	int T_texto = 14;
	int T_attr = 15;
	int T_soma = 16;
	int T_subt = 17;
	int T_mult = 18;
	int T_divi = 19;
	int T_num = 20;
	int T_blank = 21;
}
