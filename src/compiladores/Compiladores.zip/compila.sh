#!/bin/bash
java -cp antlr.jar:. IsiComp < $0